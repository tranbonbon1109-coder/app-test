# Nova Test Lab

Ứng dụng demo iOS viết bằng SwiftUI, dành cho việc thử giao diện và thao tác cơ bản.

## Chức năng
- Dashboard dark mode
- Bộ đếm tăng/giảm/reset
- Todo tester: thêm và xoá mục
- Hiển thị phiên bản iOS và model thiết bị
- Settings với các toggle

## Build bằng GitHub Actions
1. Tạo repository GitHub mới và upload toàn bộ nội dung thư mục này.
2. Push lên nhánh `main` (hoặc `master`).
3. Mở tab **Actions** → workflow **Build iOS IPA** → **Run workflow**.
4. Chờ job hoàn tất, vào phần **Artifacts** của lần chạy và tải `NovaTestLab-unsigned-ipa`.

## Lưu ý quan trọng về IPA
Workflow hiện tạo **IPA unsigned** để kiểm tra pipeline/build và lưu trữ. iPhone/iPad thông thường sẽ **không cài được IPA unsigned**.

Muốn cài lên thiết bị thật hoặc phân phối qua TestFlight, cần ký ứng dụng bằng Apple Developer signing certificate và provisioning profile hợp lệ. Đổi Bundle ID `com.example.NovaTestLab` thành Bundle ID thuộc tài khoản Apple Developer của bạn trước khi ký.

Có thể chạy thử app trong iOS Simulator bằng Xcode: mở `NovaTestLab.xcodeproj`, chọn iPhone Simulator rồi nhấn Run.
